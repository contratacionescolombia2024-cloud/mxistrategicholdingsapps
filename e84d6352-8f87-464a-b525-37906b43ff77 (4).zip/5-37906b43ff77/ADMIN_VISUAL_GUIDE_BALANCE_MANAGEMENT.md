
# 🎨 Guía Visual - Gestión de Saldos Admin

## 🗺️ Mapa de Navegación

```
📱 App
  └── 🔐 Admin Panel
      └── 👥 Gestión de Usuarios
          └── 👤 Seleccionar Usuario
              └── ⚙️ Gestión Completa de Saldos
                  ├── 💰 Balance General
                  │   ├── ➕ Sumar Sin Comisión
                  │   ├── ➕ Aumentar Con Comisión
                  │   └── ➖ Restar Balance
                  ├── 🔒 Vesting
                  │   ├── ➕ Aumentar Vesting
                  │   └── ➖ Restar Vesting
                  ├── 🏆 Torneos
                  │   ├── ➕ Aumentar Torneo
                  │   └── ➖ Restar Torneo
                  └── 🔗 Referidos
                      └── 🔗 Vincular Correo con Código
```

---

## 📊 Estructura de Balances

```
👤 Usuario
  ├── 💰 Balance General (mxi_purchased_directly)
  │   ├── Puede usarse para: TODO
  │   ├── Retirable: ✅ Sí
  │   └── Genera vesting: ✅ Sí (3% mensual)
  │
  ├── 🔒 Balance Vesting (mxi_vesting_locked)
  │   ├── Puede usarse para: NADA (bloqueado)
  │   ├── Retirable: ❌ No (hasta lanzamiento)
  │   └── Genera vesting: ❌ No
  │
  ├── 🏆 Balance Torneos (mxi_from_challenges)
  │   ├── Puede usarse para: Torneos
  │   ├── Retirable: ⚠️ Con 5 referidos activos
  │   └── Genera vesting: ❌ No
  │
  └── 💵 Balance Comisiones (mxi_from_unified_commissions)
      ├── Puede usarse para: Torneos
      ├── Retirable: ✅ Sí
      └── Genera vesting: ❌ No
```

---

## 🎯 Matriz de Decisión

### ¿Qué Acción Usar?

```
┌─────────────────────────────────────────────────────────────┐
│ ¿Necesitas generar comisiones para referidores?            │
└─────────────────────────────────────────────────────────────┘
         │
         ├─ SÍ → "Aumentar Con Comisión"
         │        └─ Genera: 5% + 2% + 1%
         │
         └─ NO → ¿Qué tipo de balance?
                  │
                  ├─ General → "Sumar Sin Comisión"
                  ├─ Vesting → "Aumentar Vesting"
                  └─ Torneo → "Aumentar Torneo"
```

---

## 🔄 Flujo de Comisiones

### Cuando usas "Aumentar Con Comisión"

```
                    100 MXI
                      ↓
              ┌───────────────┐
              │   Usuario A   │
              │  +100 MXI 💰  │
              └───────────────┘
                      ↓
              ┌───────────────┐
              │ Referidor B   │
              │  +5 MXI (5%)  │ ← Nivel 1
              └───────────────┘
                      ↓
              ┌───────────────┐
              │ Referidor C   │
              │  +2 MXI (2%)  │ ← Nivel 2
              └───────────────┘
                      ↓
              ┌───────────────┐
              │ Referidor D   │
              │  +1 MXI (1%)  │ ← Nivel 3
              └───────────────┘

Total Distribuido: 108 MXI
```

---

## 🎨 Código de Colores

### En la Interfaz

```
🟢 Verde   → Añadir/Aumentar (acciones positivas)
🔴 Rojo    → Restar (acciones destructivas)
🔵 Azul    → Acciones especiales (con comisión, vincular)
🟣 Morado  → Vesting (bloqueado)
🟡 Amarillo → Torneos (condicional)
```

### Ejemplos Visuales

```
┌─────────────────────────────────┐
│ 🟢 Sumar Sin Comisión           │  ← Verde: Añadir
└─────────────────────────────────┘

┌─────────────────────────────────┐
│ 🔵 Aumentar Con Comisión        │  ← Azul: Especial
└─────────────────────────────────┘

┌─────────────────────────────────┐
│ 🔴 Restar Balance               │  ← Rojo: Restar
└─────────────────────────────────┘

┌─────────────────────────────────┐
│ 🟣 Aumentar Vesting             │  ← Morado: Vesting
└─────────────────────────────────┘

┌─────────────────────────────────┐
│ 🟡 Aumentar Torneo              │  ← Amarillo: Torneo
└─────────────────────────────────┘
```

---

## 📱 Mockup de Interfaz

### Vista de Categorías

```
╔═══════════════════════════════════════════════════════╗
║  ⚙️ Gestión Completa de Saldos                        ║
╠═══════════════════════════════════════════════════════╣
║                                                       ║
║  💰 Balance General                                   ║
║  ┌─────────┐ ┌─────────┐ ┌─────────┐               ║
║  │ 🟢 Sumar│ │ 🔵 Aumen│ │ 🔴 Resta│               ║
║  │ Sin Com │ │ tar Con │ │ r Balan │               ║
║  │ isión   │ │ Comisión│ │ ce      │               ║
║  └─────────┘ └─────────┘ └─────────┘               ║
║                                                       ║
║  🔒 Vesting                                           ║
║  ┌─────────┐ ┌─────────┐                            ║
║  │ 🟣 Aumen│ │ 🔴 Resta│                            ║
║  │ tar Ves │ │ r Vesti │                            ║
║  │ ting    │ │ ng      │                            ║
║  └─────────┘ └─────────┘                            ║
║                                                       ║
║  🏆 Torneos                                           ║
║  ┌─────────┐ ┌─────────┐                            ║
║  │ 🟡 Aumen│ │ 🔴 Resta│                            ║
║  │ tar Tor │ │ r Torne │                            ║
║  │ neo     │ │ o       │                            ║
║  └─────────┘ └─────────┘                            ║
║                                                       ║
║  🔗 Referidos                                         ║
║  ┌───────────────────────────┐                       ║
║  │ 🔵 Vincular Correo        │                       ║
║  │    con Código             │                       ║
║  └───────────────────────────┘                       ║
╚═══════════════════════════════════════════════════════╝
```

### Modal de Acción

```
╔═══════════════════════════════════════════════════════╗
║  ➕ Sumar Saldo Balance General                       ║
║  Sin generar comisión de referido                     ║
╠═══════════════════════════════════════════════════════╣
║                                                       ║
║  Usuario: Juan Pérez                                  ║
║                                                       ║
║  Cantidad de MXI                                      ║
║  ┌─────────────────────────────────────────────┐     ║
║  │ 100.00                                      │     ║
║  └─────────────────────────────────────────────┘     ║
║                                                       ║
║  ┌─────────────────────────────────────────────┐     ║
║  │          ✅ Añadir MXI                      │     ║
║  └─────────────────────────────────────────────┘     ║
║                                                       ║
╚═══════════════════════════════════════════════════════╝
```

---

## 🔍 Comparación Visual

### Sumar Sin Comisión vs Con Comisión

```
┌─────────────────────────────────────────────────────┐
│ SIN COMISIÓN                                        │
├─────────────────────────────────────────────────────┤
│                                                     │
│  Admin añade 100 MXI                                │
│         ↓                                           │
│  Usuario recibe 100 MXI                             │
│         ↓                                           │
│  Referidores: 0 MXI                                 │
│                                                     │
│  Total: 100 MXI                                     │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│ CON COMISIÓN                                        │
├─────────────────────────────────────────────────────┤
│                                                     │
│  Admin añade 100 MXI                                │
│         ↓                                           │
│  Usuario recibe 100 MXI                             │
│         ↓                                           │
│  Referidor 1: +5 MXI (5%)                           │
│  Referidor 2: +2 MXI (2%)                           │
│  Referidor 3: +1 MXI (1%)                           │
│                                                     │
│  Total: 108 MXI                                     │
└─────────────────────────────────────────────────────┘
```

---

## 📊 Dashboard de Balance

### Vista Completa del Usuario

```
╔═══════════════════════════════════════════════════════╗
║  👤 Juan Pérez (juan@ejemplo.com)                     ║
╠═══════════════════════════════════════════════════════╣
║                                                       ║
║  💎 Balance Total: 1,250.00 MXI                       ║
║                                                       ║
║  ┌─────────────────────────────────────────────┐     ║
║  │ 💰 Balance General                          │     ║
║  │ 800.00 MXI                                  │     ║
║  │ ✏️ Editable                                  │     ║
║  └─────────────────────────────────────────────┘     ║
║                                                       ║
║  ┌─────────────────────────────────────────────┐     ║
║  │ 🔒 Balance Vesting                          │     ║
║  │ 250.00 MXI                                  │     ║
║  │ ✏️ Editable                                  │     ║
║  └─────────────────────────────────────────────┘     ║
║                                                       ║
║  ┌─────────────────────────────────────────────┐     ║
║  │ 🏆 Balance Torneos                          │     ║
║  │ 150.00 MXI                                  │     ║
║  │ ✏️ Editable                                  │     ║
║  └─────────────────────────────────────────────┘     ║
║                                                       ║
║  ┌─────────────────────────────────────────────┐     ║
║  │ 💵 Balance Comisiones                       │     ║
║  │ 50.00 MXI                                   │     ║
║  │ ℹ️ Solo lectura                              │     ║
║  └─────────────────────────────────────────────┘     ║
║                                                       ║
╚═══════════════════════════════════════════════════════╝
```

---

## 🎯 Iconografía

### Iconos por Acción

```
➕ Añadir/Aumentar
➖ Restar
🔗 Vincular
💰 Balance General
🔒 Vesting (Bloqueado)
🏆 Torneos
💵 Comisiones
👤 Usuario
👥 Referidos
✅ Éxito
❌ Error
⚠️ Advertencia
💡 Información
🔐 Seguridad
📊 Métricas
⚙️ Gestión
```

---

## 🚦 Estados de Validación

### Feedback Visual

```
┌─────────────────────────────────────────────────────┐
│ ✅ ÉXITO                                            │
├─────────────────────────────────────────────────────┤
│ Se añadieron 100 MXI al balance general             │
│ sin generar comisión                                │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│ ❌ ERROR                                            │
├─────────────────────────────────────────────────────┤
│ Balance insuficiente. Balance actual: 50 MXI        │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│ ⚠️ ADVERTENCIA                                      │
├─────────────────────────────────────────────────────┤
│ ¿Estás seguro de restar 100 MXI del balance        │
│ general?                                            │
│                                                     │
│ [Cancelar]  [Restar]                                │
└─────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────┐
│ 💡 INFORMACIÓN                                      │
├─────────────────────────────────────────────────────┤
│ Las comisiones se calcularán automáticamente        │
│ basadas en la cantidad de MXI comprados             │
└─────────────────────────────────────────────────────┘
```

---

## 📈 Progresión de Acciones

### Flujo Completo

```
1️⃣ INICIO
   ↓
2️⃣ SELECCIONAR USUARIO
   ↓
3️⃣ ELEGIR CATEGORÍA
   │
   ├─ Balance General
   ├─ Vesting
   ├─ Torneos
   └─ Referidos
   ↓
4️⃣ ELEGIR ACCIÓN
   │
   ├─ Añadir/Aumentar
   └─ Restar
   ↓
5️⃣ INGRESAR DATOS
   │
   ├─ Monto
   └─ Código (si aplica)
   ↓
6️⃣ VALIDACIÓN
   │
   ├─ ✅ Válido → Continuar
   └─ ❌ Inválido → Mostrar error
   ↓
7️⃣ CONFIRMACIÓN
   │
   ├─ Confirmar
   └─ Cancelar
   ↓
8️⃣ EJECUCIÓN
   ↓
9️⃣ RESULTADO
   │
   ├─ ✅ Éxito → Actualizar UI
   └─ ❌ Error → Mostrar mensaje
   ↓
🔟 FIN
```

---

## 🎓 Leyenda de Símbolos

```
✅ = Permitido / Éxito
❌ = No permitido / Error
⚠️ = Advertencia / Cuidado
💡 = Información / Tip
🔒 = Bloqueado / Seguro
🔓 = Desbloqueado / Disponible
➕ = Añadir / Aumentar
➖ = Restar / Disminuir
🔗 = Vincular / Conectar
💰 = Dinero / Balance
🏆 = Premio / Torneo
👤 = Usuario
👥 = Múltiples usuarios
📊 = Estadísticas / Métricas
⚙️ = Configuración / Gestión
🎯 = Objetivo / Meta
🚀 = Rápido / Acción
```

---

**Última Actualización:** 2025
**Versión:** 1.0
