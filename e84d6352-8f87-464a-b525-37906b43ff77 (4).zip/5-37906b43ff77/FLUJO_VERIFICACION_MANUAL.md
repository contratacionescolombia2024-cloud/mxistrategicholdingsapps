
# Flujo de Verificación Manual de Pagos - Diagrama Visual

## 🔄 Flujo General del Sistema

```
┌─────────────────────────────────────────────────────────────────┐
│                    SISTEMA DE PAGOS MXI                          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │   Usuario Realiza Pago en NOWPayments   │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │     Pago Registrado en Base de Datos    │
        │         Status: "waiting"                │
        └─────────────────────────────────────────┘
                              │
                              ▼
                    ┌─────────┴─────────┐
                    │                   │
                    ▼                   ▼
        ┌───────────────────┐  ┌───────────────────┐
        │   VERIFICACIÓN    │  │   VERIFICACIÓN    │
        │    AUTOMÁTICA     │  │     MANUAL        │
        └───────────────────┘  └───────────────────┘
                    │                   │
                    └─────────┬─────────┘
                              ▼
        ┌─────────────────────────────────────────┐
        │    Pago Confirmado y MXI Acreditado     │
        │         Status: "confirmed"              │
        └─────────────────────────────────────────┘
```

## 📱 Flujo de Verificación Manual - Usuario

```
┌─────────────────────────────────────────────────────────────────┐
│                    INICIO - USUARIO                              │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Usuario Completa Pago en NOWPayments   │
        │  (Envía USDT a dirección proporcionada) │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │     Espera 10-15 Minutos                │
        │  (Tiempo normal de confirmación)        │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │   ¿Pago Acreditado Automáticamente?     │
        └─────────────────────────────────────────┘
                    │                   │
                    │ SÍ                │ NO
                    ▼                   ▼
        ┌───────────────────┐  ┌───────────────────┐
        │   ✅ FIN          │  │  Continuar con    │
        │  (Todo OK)        │  │  Verificación     │
        │                   │  │     Manual        │
        └───────────────────┘  └───────────────────┘
                                        │
                                        ▼
        ┌─────────────────────────────────────────┐
        │  Usuario va a "Historial de Pagos"      │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Encuentra Pago con Status "Pendiente"  │
        │  Ve botón "Verificar Pago"              │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Usuario hace clic en "Verificar Pago"  │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Sistema muestra "Verificando..."       │
        │  (Loading state)                        │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Edge Function: manual-verify-payment   │
        │  - Autentica usuario                    │
        │  - Verifica propiedad del pago          │
        │  - Consulta NOWPayments API             │
        │  - Verifica estado del pago             │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │   ¿Pago Confirmado en NOWPayments?      │
        └─────────────────────────────────────────┘
                    │                   │
                    │ SÍ                │ NO
                    ▼                   ▼
        ┌───────────────────┐  ┌───────────────────┐
        │  Acreditar MXI    │  │  Actualizar       │
        │  - Actualizar     │  │  Status           │
        │    balance        │  │  - Mostrar        │
        │  - Actualizar     │  │    mensaje        │
        │    métricas       │  │  - Sugerir        │
        │  - Marcar como    │  │    esperar        │
        │    confirmado     │  │                   │
        └───────────────────┘  └───────────────────┘
                    │                   │
                    ▼                   ▼
        ┌───────────────────┐  ┌───────────────────┐
        │  Mostrar Mensaje  │  │  Mostrar Mensaje  │
        │  de Éxito         │  │  Informativo      │
        │  "✅ Pago         │  │  "ℹ️ Pago aún    │
        │  acreditado       │  │  no confirmado"   │
        │  exitosamente"    │  │                   │
        │  + Nuevo Balance  │  │  "Intenta más     │
        │                   │  │  tarde"           │
        └───────────────────┘  └───────────────────┘
                    │                   │
                    ▼                   ▼
        ┌───────────────────┐  ┌───────────────────┐
        │  Actualizar UI    │  │  Usuario puede    │
        │  - Nuevo balance  │  │  intentar         │
        │  - Status         │  │  nuevamente       │
        │    "confirmado"   │  │  más tarde        │
        │  - Ocultar botón  │  │                   │
        └───────────────────┘  └───────────────────┘
                    │
                    ▼
        ┌─────────────────────────────────────────┐
        │              ✅ FIN                      │
        │         (Pago Acreditado)                │
        └─────────────────────────────────────────┘
```

## 👨‍💼 Flujo de Verificación Manual - Administrador

```
┌─────────────────────────────────────────────────────────────────┐
│                  INICIO - ADMINISTRADOR                          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Usuario Reporta Problema con Pago      │
        │  - Pago no acreditado                   │
        │  - Proporciona Order ID                 │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Admin Verifica en NOWPayments          │
        │  Dashboard                              │
        │  - Confirma que pago existe             │
        │  - Verifica estado                      │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Admin va a Panel de Administración     │
        │  → "Manual Payment Credit"              │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Admin Ingresa Order ID                 │
        │  Ejemplo: MXI-1764082913255-cop99k      │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Admin hace clic en "Buscar Pago"       │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Sistema Busca Pago en Base de Datos    │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │         ¿Pago Encontrado?                │
        └─────────────────────────────────────────┘
                    │                   │
                    │ SÍ                │ NO
                    ▼                   ▼
        ┌───────────────────┐  ┌───────────────────┐
        │  Mostrar Detalles │  │  Mostrar Error    │
        │  del Pago:        │  │  "Pago no         │
        │  - Order ID       │  │  encontrado"      │
        │  - Payment ID     │  │                   │
        │  - Status         │  │  ❌ FIN           │
        │  - Monto USD      │  │                   │
        │  - Monto MXI      │  └───────────────────┘
        │  - Fase           │
        │  - Fecha          │
        │                   │
        │  Detalles Usuario:│
        │  - Email          │
        │  - Nombre         │
        │  - Balance actual │
        │  - USDT contrib.  │
        └───────────────────┘
                    │
                    ▼
        ┌─────────────────────────────────────────┐
        │  Admin Revisa Información               │
        │  - Verifica que todo sea correcto       │
        │  - Confirma monto                       │
        │  - Verifica usuario                     │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │    ¿Pago Ya Está Confirmado?            │
        └─────────────────────────────────────────┘
                    │                   │
                    │ SÍ                │ NO
                    ▼                   ▼
        ┌───────────────────┐  ┌───────────────────┐
        │  Mostrar Mensaje  │  │  Mostrar Botón    │
        │  "✅ Ya           │  │  "Verificar y     │
        │  Acreditado"      │  │  Acreditar Pago"  │
        │                   │  │                   │
        │  ❌ FIN           │  └───────────────────┘
        │  (No se puede     │            │
        │  acreditar 2x)    │            ▼
        └───────────────────┘  ┌───────────────────┐
                               │  Admin hace clic  │
                               │  en botón         │
                               └───────────────────┘
                                        │
                                        ▼
        ┌─────────────────────────────────────────┐
        │  Sistema muestra confirmación:          │
        │  "¿Estás seguro de que deseas           │
        │  verificar y acreditar este pago?"      │
        │                                         │
        │  [Cancelar]  [Verificar y Acreditar]   │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Admin confirma                         │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Sistema muestra "Verificando..."       │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Edge Function: manual-verify-payment   │
        │  - Autentica admin                      │
        │  - Verifica permisos de admin           │
        │  - Consulta NOWPayments API             │
        │  - Verifica estado del pago             │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │   ¿Pago Confirmado en NOWPayments?      │
        └─────────────────────────────────────────┘
                    │                   │
                    │ SÍ                │ NO
                    ▼                   ▼
        ┌───────────────────┐  ┌───────────────────┐
        │  Acreditar MXI    │  │  Mostrar Error    │
        │  AUTOMÁTICAMENTE: │  │  "Pago no         │
        │  - Actualizar     │  │  confirmado en    │
        │    balance user   │  │  NOWPayments"     │
        │  - Actualizar     │  │                   │
        │    métricas       │  │  Sugerir:         │
        │  - Marcar como    │  │  - Esperar        │
        │    confirmado     │  │  - Verificar en   │
        │  - Actualizar     │  │    NOWPayments    │
        │    transaction    │  │  - Intentar más   │
        │    history        │  │    tarde          │
        └───────────────────┘  └───────────────────┘
                    │                   │
                    ▼                   ▼
        ┌───────────────────┐  ┌───────────────────┐
        │  Mostrar Mensaje  │  │  Admin puede      │
        │  de Éxito:        │  │  intentar         │
        │  "✅ Pago         │  │  nuevamente       │
        │  verificado y     │  │  más tarde        │
        │  acreditado       │  │                   │
        │  exitosamente"    │  │  O contactar      │
        │                   │  │  soporte técnico  │
        │  Detalles:        │  └───────────────────┘
        │  - MXI acreditado │
        │  - Nuevo balance  │
        │  - Order ID       │
        └───────────────────┘
                    │
                    ▼
        ┌─────────────────────────────────────────┐
        │  Admin Informa al Usuario               │
        │  - Pago acreditado exitosamente         │
        │  - Nuevo balance                        │
        │  - Puede verificar en la app            │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  Admin Documenta la Intervención        │
        │  - Fecha y hora                         │
        │  - Order ID                             │
        │  - Razón de intervención manual         │
        │  - Resultado                            │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │              ✅ FIN                      │
        │    (Pago Acreditado y Usuario Notificado)│
        └─────────────────────────────────────────┘
```

## 🔐 Flujo de Seguridad y Prevención de Doble Acreditación

```
┌─────────────────────────────────────────────────────────────────┐
│         VERIFICACIÓN DE SEGURIDAD Y PREVENCIÓN                   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  1. Validar Token JWT                   │
        │     ¿Token válido?                      │
        └─────────────────────────────────────────┘
                    │                   │
                    │ SÍ                │ NO
                    ▼                   ▼
        ┌───────────────────┐  ┌───────────────────┐
        │  Continuar        │  │  ❌ Error 401     │
        └───────────────────┘  │  "Unauthorized"   │
                    │          └───────────────────┘
                    ▼
        ┌─────────────────────────────────────────┐
        │  2. Validar Sesión de Usuario           │
        │     ¿Sesión activa?                     │
        └─────────────────────────────────────────┘
                    │                   │
                    │ SÍ                │ NO
                    ▼                   ▼
        ┌───────────────────┐  ┌───────────────────┐
        │  Continuar        │  │  ❌ Error 401     │
        └───────────────────┘  │  "Invalid Session"│
                    │          └───────────────────┘
                    ▼
        ┌─────────────────────────────────────────┐
        │  3. Buscar Pago en Base de Datos        │
        │     ¿Pago existe?                       │
        └─────────────────────────────────────────┘
                    │                   │
                    │ SÍ                │ NO
                    ▼                   ▼
        ┌───────────────────┐  ┌───────────────────┐
        │  Continuar        │  │  ❌ Error 404     │
        └───────────────────┘  │  "Payment Not     │
                    │          │  Found"           │
                    ▼          └───────────────────┘
        ┌─────────────────────────────────────────┐
        │  4. Verificar Propiedad o Admin         │
        │     ¿Usuario es dueño O admin?          │
        └─────────────────────────────────────────┘
                    │                   │
                    │ SÍ                │ NO
                    ▼                   ▼
        ┌───────────────────┐  ┌───────────────────┐
        │  Continuar        │  │  ❌ Error 403     │
        └───────────────────┘  │  "Forbidden"      │
                    │          └───────────────────┘
                    ▼
        ┌─────────────────────────────────────────┐
        │  5. Verificar Estado del Pago           │
        │     ¿Ya está confirmado?                │
        └─────────────────────────────────────────┘
                    │                   │
                    │ NO                │ SÍ
                    ▼                   ▼
        ┌───────────────────┐  ┌───────────────────┐
        │  Continuar con    │  │  ✅ Retornar      │
        │  verificación     │  │  "Already         │
        └───────────────────┘  │  Credited"        │
                    │          │                   │
                    ▼          │  (No acreditar)   │
        ┌─────────────────────────────────────────┐
        │  6. Consultar NOWPayments API           │
        │     ¿API responde OK?                   │
        └─────────────────────────────────────────┘
                    │                   │
                    │ SÍ                │ NO
                    ▼                   ▼
        ┌───────────────────┐  ┌───────────────────┐
        │  Continuar        │  │  ❌ Error 500     │
        └───────────────────┘  │  "NOWPayments     │
                    │          │  API Error"       │
                    ▼          └───────────────────┘
        ┌─────────────────────────────────────────┐
        │  7. Verificar Estado en NOWPayments     │
        │     ¿Estado = "finished" o "confirmed"? │
        └─────────────────────────────────────────┘
                    │                   │
                    │ SÍ                │ NO
                    ▼                   ▼
        ┌───────────────────┐  ┌───────────────────┐
        │  ACREDITAR MXI    │  │  ✅ Actualizar    │
        │  (Ver flujo       │  │  Status           │
        │  detallado abajo) │  │  (No acreditar)   │
        └───────────────────┘  └───────────────────┘
                    │
                    ▼
        ┌─────────────────────────────────────────┐
        │  FLUJO DE ACREDITACIÓN (Atómico)        │
        │                                         │
        │  BEGIN TRANSACTION                      │
        │                                         │
        │  1. Obtener balance actual del usuario  │
        │  2. Calcular nuevo balance              │
        │  3. Actualizar users table:             │
        │     - mxi_balance                       │
        │     - usdt_contributed                  │
        │     - mxi_purchased_directly            │
        │     - is_active_contributor = true      │
        │                                         │
        │  4. Actualizar metrics table:           │
        │     - total_usdt_contributed            │
        │     - total_mxi_distributed             │
        │     - total_tokens_sold                 │
        │                                         │
        │  5. Actualizar payments table:          │
        │     - status = 'confirmed'              │
        │     - confirmed_at = NOW()              │
        │                                         │
        │  6. Actualizar transaction_history:     │
        │     - status = 'finished'               │
        │     - completed_at = NOW()              │
        │                                         │
        │  COMMIT TRANSACTION                     │
        │                                         │
        │  ✅ Si todo OK: Retornar éxito          │
        │  ❌ Si error: ROLLBACK y retornar error │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │  8. Logging Completo                    │
        │     - Request ID único                  │
        │     - Todos los pasos                   │
        │     - Resultado final                   │
        │     - Timestamp                         │
        └─────────────────────────────────────────┘
                              │
                              ▼
        ┌─────────────────────────────────────────┐
        │              ✅ FIN                      │
        │    (Operación Segura y Completa)        │
        └─────────────────────────────────────────┘
```

## 📊 Comparación de Métodos

```
┌─────────────────────────────────────────────────────────────────┐
│              MÉTODOS DE VERIFICACIÓN DE PAGOS                    │
└─────────────────────────────────────────────────────────────────┘

┌──────────────────┬──────────────────┬──────────────────┬──────────────────┐
│   CARACTERÍSTICA │   WEBHOOK        │   AUTO-VERIFY    │   MANUAL         │
│                  │   (Automático)   │   (Polling)      │   (Usuario/Admin)│
├──────────────────┼──────────────────┼──────────────────┼──────────────────┤
│ Activación       │ NOWPayments      │ Cron Job         │ Usuario/Admin    │
│                  │ envía webhook    │ (cada X min)     │ hace clic        │
├──────────────────┼──────────────────┼──────────────────┼──────────────────┤
│ Tiempo           │ Inmediato        │ Cada 30 min      │ Inmediato        │
│                  │ (1-5 min)        │ (retraso)        │ (5-10 seg)       │
├──────────────────┼──────────────────┼──────────────────┼──────────────────┤
│ Confiabilidad    │ Alta             │ Muy Alta         │ Muy Alta         │
│                  │ (depende de      │ (garantizado)    │ (bajo demanda)   │
│                  │ entrega)         │                  │                  │
├──────────────────┼──────────────────┼──────────────────┼──────────────────┤
│ Uso de Recursos  │ Bajo             │ Medio            │ Bajo             │
│                  │ (solo cuando     │ (periódico)      │ (solo cuando     │
│                  │ hay webhook)     │                  │ se solicita)     │
├──────────────────┼──────────────────┼──────────────────┼──────────────────┤
│ Caso de Uso      │ Método           │ Respaldo para    │ Cuando fallan    │
│                  │ principal        │ webhooks         │ otros métodos    │
│                  │                  │ perdidos         │                  │
├──────────────────┼──────────────────┼──────────────────┼──────────────────┤
│ Ventaja          │ Más rápido       │ Más confiable    │ Control total    │
│ Principal        │                  │                  │ del usuario      │
├──────────────────┼──────────────────┼──────────────────┼──────────────────┤
│ Desventaja       │ Puede fallar     │ Tiene retraso    │ Requiere acción  │
│ Principal        │ si webhook       │                  │ manual           │
│                  │ no llega         │                  │                  │
└──────────────────┴──────────────────┴──────────────────┴──────────────────┘

RECOMENDACIÓN:
✅ Webhook: Método principal (95% de los casos)
✅ Auto-Verify: Respaldo automático (4% de los casos)
✅ Manual: Último recurso o verificación inmediata (1% de los casos)
```

## 🎯 Casos de Uso Visuales

### Caso 1: Flujo Normal (Webhook Funciona)
```
Usuario Paga → Webhook Recibido → MXI Acreditado → ✅ FIN
   (1 min)         (2 min)            (inmediato)
```

### Caso 2: Webhook Falla, Auto-Verify Funciona
```
Usuario Paga → Webhook Falla → Auto-Verify → MXI Acreditado → ✅ FIN
   (1 min)       (timeout)      (30 min)       (inmediato)
```

### Caso 3: Todo Falla, Usuario Verifica Manualmente
```
Usuario Paga → Webhook Falla → Auto-Verify Falla → Usuario Verifica → ✅ FIN
   (1 min)       (timeout)        (timeout)         Manualmente
                                                     (inmediato)
```

### Caso 4: Admin Interviene
```
Usuario Reporta → Admin Busca → Admin Verifica → MXI Acreditado → ✅ FIN
   Problema         Pago          Manualmente       (inmediato)
```

---

**Nota**: Todos los flujos usan la misma lógica de acreditación para garantizar consistencia y prevenir doble acreditación.

**Fecha**: 15 de Enero, 2025  
**Versión**: 1.0  
**Estado**: ✅ Documentación Completa
